# Bundle Instructions

- Generated: 2025-09-22T19:02:38Z
- Root: /home/graham/workspace/experiments/shared-dev-tools
- Files included: 35
- Structure: Original selected files under their repo-relative paths.
- Sidecars: manifest.json (checksums), index.json (CLI JSON summary) if present.

Directory structure (relative file list):
- .github/CODEOWNERS
- .github/workflows/ci.yml
- .gitignore
- .python-version
- AGENTS.md
- CODE_OF_CONDUCT.md
- CONTRIBUTING.md
- LICENSE
- PREAMBLE.md
- README.md
- SECURITY.md
- STATE_OF_PROJECT.md
- bundle.md
- docs/HAPPYPATH_GUIDE.md
- docs/MCP_USAGE.md
- docs/SMOKES_GUIDE.md
- docs/comments.md
- docs/token_limits.md
- mcp/bundle-files-mcp/index.mjs
- mcp/bundle-files-mcp/package-lock.json
- mcp/bundle-files-mcp/package.json
- package-lock.json
- package.json
- pyproject.toml
- scripts/run-bundle-mcp.sh
- src/shared_dev_tools/__init__.py
- src/shared_dev_tools/cli.py
- tests/conftest.py
- tests/smokes/test_cli_archive_files_smoke.py
- tests/smokes/test_cli_bundle_smoke.py
- tests/smokes/test_cli_changed_since_smoke.py
- tests/smokes/test_cli_strict_and_archive_smokes.py
- tmp/mcp-small/HAPPYPATH_GUIDE.md
- tmp/mcp-small/MCP_USAGE.md
- tmp/mcp-small/SMOKES_GUIDE.md

Notes:
- Use the Markdown bundle parts (*.md) alongside this archive for LLM ingestion.
