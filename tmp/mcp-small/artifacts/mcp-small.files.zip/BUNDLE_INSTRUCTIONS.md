# Bundle Instructions

- Generated: 2025-09-22T18:35:21Z
- Root: /home/graham/workspace/experiments/shared-dev-tools/tmp/mcp-small
- Files included: 3
- Structure: Original selected files under their repo-relative paths.
- Sidecars: manifest.json (checksums), index.json (CLI JSON summary) if present.

Directory structure (relative file list):
- HAPPYPATH_GUIDE.md
- MCP_USAGE.md
- SMOKES_GUIDE.md

Notes:
- Use the Markdown bundle parts (*.md) alongside this archive for LLM ingestion.
